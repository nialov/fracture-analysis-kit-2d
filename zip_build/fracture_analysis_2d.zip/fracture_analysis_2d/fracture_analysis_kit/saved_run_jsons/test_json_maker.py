import json

with open("test_run.json", mode="w+") as json_file:
    json.dump([["trace", "branch", "node", "area", "name", "group"]], fp=json_file)

with open("test_run.json", mode="r") as json_file:
    print(json.load(json_file))

