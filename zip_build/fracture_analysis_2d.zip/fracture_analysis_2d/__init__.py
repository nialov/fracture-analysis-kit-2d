import os
import sys
from pathlib import Path



# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load FractureAnalysis2D class from file FractureAnalysis2D.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    currentPath = os.path.dirname(__file__)
    install_dir = str((Path(__file__) / Path("install_dir")).resolve())
    sys.path.append(os.path.abspath(currentPath))

    # Setup Pythonpath for when user has no administrator access and modules are in user Python folder
    roaming_folder = os.environ['APPDATA']
    try:
        os.environ['PYTHONPATH'] += rf';{roaming_folder}\Python\Python37\site-packages;{install_dir}'
    except KeyError:
        os.environ['PYTHONPATH'] = rf'{roaming_folder}\Python\Python37\site-packages;{install_dir}'

    # Checks if external Python modules are installed and functional.
    from install_script import install, check_installations
    check_installations()


    from .fracture_analysis_2d import FractureAnalysis2D

    return FractureAnalysis2D(iface)



